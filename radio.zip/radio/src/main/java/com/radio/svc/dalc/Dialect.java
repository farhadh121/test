package com.radio.svc.dalc;

/**
 * Created by IntelliJ IDEA.
 * User: saman
 * Date: 5/10/12
 * Time: 9:23 AM
 * To change this template use CommonFile | Settings | CommonFile Templates.
 */
public enum Dialect {

    mssql,
    oracle,
    mysql

}
