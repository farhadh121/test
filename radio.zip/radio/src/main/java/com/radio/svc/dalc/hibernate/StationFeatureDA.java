package com.radio.svc.dalc.hibernate;

import com.radio.entity.hibernate.StationFeatureEntity;
import com.radio.svc.dalc.IStationFeatureDA;

/**
 * Created by saman on 9/21/14.
 */
public class StationFeatureDA extends GenericDA<StationFeatureEntity, Long> implements IStationFeatureDA {
}
