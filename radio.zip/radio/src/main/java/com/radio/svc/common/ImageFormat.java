package com.radio.svc.common;

/**
 * Created with IntelliJ IDEA.
 * User: farhad
 * Date: 5/14/14
 * Time: 10:47 PM
 * To change this template use CommonFile | Settings | CommonFile Templates.
 */
public class ImageFormat {
    /**
     * Jpeg format
     */
    public static final String JPG = "jpg";
    /**
     * Pong format
     */
    public static final String PNG = "png";
    /**
     * Bitmap format
     */
    public static final String BMP = "bmp";

}
