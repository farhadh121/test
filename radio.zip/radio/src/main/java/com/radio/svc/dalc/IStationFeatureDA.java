package com.radio.svc.dalc;

import com.radio.entity.hibernate.StationFeatureEntity;

/**
 * Created by farhad on 9/21/14.
 */
public interface IStationFeatureDA extends IGenericDA<StationFeatureEntity, Long>  {
}
