package com.radio.svc.common;

/**
 * Created with IntelliJ IDEA.
 * User: farhad
 * Date: 5/14/14
 * Time: 10:42 PM
 * To change this template use CommonFile | Settings | CommonFile Templates.
 */
public class SongFormat {

    /**
     * MP3 foramt
     */
    public static final String MP3 = "mp3";
    /**
     * WMV format
     */
    public static final String WMV = "wmv";
    /**
     * WAV format
     */
    public static final String WAV = "wav";
    /**
     * OGG format
     */
    public static final String OGG = "ogg";


}
