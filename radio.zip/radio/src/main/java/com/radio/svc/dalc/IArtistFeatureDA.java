package com.radio.svc.dalc;

import com.radio.entity.hibernate.ArtistFeatureEntity;

/**
 * Created by farhad on 8/30/14.
 */
public interface IArtistFeatureDA extends IGenericDA<ArtistFeatureEntity, Long> {
}
