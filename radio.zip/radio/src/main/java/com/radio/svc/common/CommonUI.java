package com.radio.svc.common;

/**
 * Created with IntelliJ IDEA.
 * User: farhad
 * Date: 6/30/14
 * Time: 12:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommonUI {

    /**
     * image width for admin pages
     */
    private String adminImageWidth;
    /**
     * image height for admin pages
     */
    private String adminImageHeight;

    public String getAdminImageWidth() {
        return adminImageWidth;
    }

    public void setAdminImageWidth(String adminImageWidth) {
        this.adminImageWidth = adminImageWidth;
    }

    public String getAdminImageHeight() {
        return adminImageHeight;
    }

    public void setAdminImageHeight(String adminImageHeight) {
        this.adminImageHeight = adminImageHeight;
    }
}
