package com.radio.svc.dalc.hibernate;

import com.radio.entity.hibernate.ArtistFeatureEntity;
import com.radio.svc.dalc.IArtistFeatureDA;

/**
 * Created by saman on 8/30/14.
 */
public class ArtistFeatureDA extends GenericDA<ArtistFeatureEntity, Long> implements IArtistFeatureDA {
}
